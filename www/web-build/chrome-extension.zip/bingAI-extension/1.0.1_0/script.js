if (navigator.brave && !document.documentElement.getAttribute('bing-ai-for-brave')) {
	location.href = 'https://github.com/patrik-martinko/app-bing-ai-for-chrome#brave-browser';
}